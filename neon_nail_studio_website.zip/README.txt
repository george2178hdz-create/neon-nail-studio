# Neon Nail Studio — Free Website

This is a ready-to-publish one-page website built from the information in the supplied screenshot.

## Included
- `index.html` — website
- `style.css` — design
- `nails-1.jpg`, `nails-2.jpg`, `nails-3.jpg` — crops from the supplied screenshot

## Publish for free with GitHub Pages
1. Create a free GitHub account at github.com.
2. Create a new repository named `neon-nail-studio`.
3. Upload all five files.
4. Open the repository's **Settings → Pages**.
5. Select **Deploy from a branch**, choose `main`, and save.
6. GitHub will give you a free website address.

The site also includes clickable phone and Google Maps direction buttons.
